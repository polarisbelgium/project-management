"""Outreach agent. Nothing is sent without your approval.
Usage:
  python main.py project "describe your project"
  python main.py research        # find prospects
  python main.py draft           # draft proposals for new prospects
  python main.py followups       # draft follow-ups for silent prospects
  python main.py queue           # approve / edit / reject drafts
  python main.py offer ID "details"   # log an offer you received
  python main.py report
"""
import sys, datetime as dt
from agent import db, llm, mailer

def project():
    with db.conn() as c:
        r = c.execute("SELECT description FROM project WHERE id=1").fetchone()
    if not r: sys.exit("Set a project first: python main.py project \"...\"")
    return r["description"]

def cmd_project(text):
    with db.conn() as c:
        c.execute("INSERT OR REPLACE INTO project VALUES(1,?)", (text,))
    print("Saved.")

def cmd_research():
    found = llm.research(project())
    with db.conn() as c:
        for p in found:
            c.execute("INSERT INTO prospects(name,company,email,why_fit) VALUES(?,?,?,?)",
                      (p["name"], p["company"], p.get("email", ""), p["why_fit"]))
            print(f"+ {p['name']} ({p['company']})")

def _queue(c, pid, kind, d):
    c.execute("INSERT INTO actions(prospect_id,kind,subject,body,created) VALUES(?,?,?,?,?)",
              (pid, kind, d["subject"], d["body"], db.now()))

def cmd_draft():
    proj = project()
    with db.conn() as c:
        for p in c.execute("SELECT * FROM prospects WHERE status='new'").fetchall():
            _queue(c, p["id"], "proposal", llm.draft(proj, p))
            c.execute("UPDATE prospects SET status='drafted' WHERE id=?", (p["id"],))
    print("Drafts added. Run: python main.py queue")

def cmd_followups(days=3):
    proj, cutoff = project(), (dt.datetime.now() - dt.timedelta(days=days)).isoformat()
    with db.conn() as c:
        rows = c.execute("SELECT * FROM prospects WHERE status='contacted' AND last_contact<?",
                         (cutoff,)).fetchall()
        for p in rows:
            hist = "\n".join(r["body"] for r in c.execute(
                "SELECT body FROM actions WHERE prospect_id=? AND status='sent'", (p["id"],)))
            _queue(c, p["id"], "followup", llm.draft(proj, p, "followup", hist))
    print(f"{len(rows)} follow-up(s) drafted.")

def cmd_queue():
    with db.conn() as c:
        items = c.execute("""SELECT a.*, p.name, p.email FROM actions a
                             JOIN prospects p ON p.id=a.prospect_id
                             WHERE a.status='pending'""").fetchall()
        if not items: return print("Nothing pending.")
        for a in items:
            print(f"\n--- [{a['kind']}] to {a['name']} <{a['email'] or 'no email'}>\n"
                  f"Subject: {a['subject']}\n\n{a['body']}\n")
            ch = input("(a)pprove  (e)dit  (r)eject  (s)kip: ").strip().lower()
            if ch == "e":
                body = input("New body: ")
                c.execute("UPDATE actions SET body=? WHERE id=?", (body, a["id"]))
                ch = "a"; a = dict(a, body=body)
            if ch == "a":
                if mailer.configured() and a["email"]:
                    mailer.send(a["email"], a["subject"], a["body"])
                    print("Sent.")
                else:
                    print("Email not configured / no address. Copy the text above and send manually.")
                c.execute("UPDATE actions SET status='sent' WHERE id=?", (a["id"],))
                c.execute("UPDATE prospects SET status='contacted', last_contact=? WHERE id=?",
                          (db.now(), a["prospect_id"]))
            elif ch == "r":
                c.execute("UPDATE actions SET status='rejected' WHERE id=?", (a["id"],))

def cmd_offer(pid, details):
    with db.conn() as c:
        c.execute("INSERT INTO offers(prospect_id,details,created) VALUES(?,?,?)",
                  (pid, details, db.now()))
        c.execute("UPDATE prospects SET status='offer' WHERE id=?", (pid,))
    print("Logged.")

def cmd_report():
    with db.conn() as c:
        data = {
            "prospects": [dict(r) for r in c.execute("SELECT id,name,company,status FROM prospects")],
            "offers": [dict(r) for r in c.execute("SELECT * FROM offers")],
            "pending_approvals": c.execute("SELECT COUNT(*) FROM actions WHERE status='pending'").fetchone()[0],
        }
    print(llm.report(data))

if __name__ == "__main__":
    db.init()
    a = sys.argv[1:]
    if not a: print(__doc__)
    elif a[0] == "project": cmd_project(a[1])
    elif a[0] == "research": cmd_research()
    elif a[0] == "draft": cmd_draft()
    elif a[0] == "followups": cmd_followups()
    elif a[0] == "queue": cmd_queue()
    elif a[0] == "offer": cmd_offer(int(a[1]), a[2])
    elif a[0] == "report": cmd_report()
    else: print(__doc__)
