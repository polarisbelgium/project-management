import os, smtplib
from email.message import EmailMessage
from dotenv import load_dotenv
load_dotenv()

def configured():
    return bool(os.getenv("SMTP_USER") and os.getenv("SMTP_PASS"))

def send(to, subject, body):
    m = EmailMessage()
    m["From"] = f"{os.getenv('SENDER_NAME','')} <{os.getenv('SMTP_USER')}>"
    m["To"], m["Subject"] = to, subject
    m.set_content(body)
    with smtplib.SMTP(os.getenv("SMTP_HOST"), int(os.getenv("SMTP_PORT", 587))) as s:
        s.starttls()
        s.login(os.getenv("SMTP_USER"), os.getenv("SMTP_PASS"))
        s.send_message(m)
