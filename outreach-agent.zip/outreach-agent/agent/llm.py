import os, json, re
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
client = Anthropic()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")

def _text(resp):
    return "".join(b.text for b in resp.content if b.type == "text")

def research(project, n=8):
    """Find prospective industry players using web search."""
    resp = client.messages.create(
        model=MODEL, max_tokens=4000,
        tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 6}],
        messages=[{"role": "user", "content":
            f"Project:\n{project}\n\nFind {n} real companies/people likely to be interested "
            "(partners, investors, clients, suppliers). Return ONLY a JSON list of objects "
            'with keys: name, company, email (empty string if unknown), why_fit.'}])
    m = re.search(r"\[.*\]", _text(resp), re.S)
    return json.loads(m.group(0)) if m else []

def draft(project, prospect, kind="proposal", history=""):
    prompt = (f"Project:\n{project}\n\nProspect: {prospect['name']} at {prospect['company']}. "
              f"Why fit: {prospect['why_fit']}\n")
    if kind == "followup":
        prompt += f"Previous messages:\n{history}\nWrite a short, polite follow-up.\n"
    else:
        prompt += "Write a concise, personalized proposal email.\n"
    prompt += 'Return ONLY JSON: {"subject": "...", "body": "..."}'
    resp = client.messages.create(model=MODEL, max_tokens=1200,
                                  messages=[{"role": "user", "content": prompt}])
    m = re.search(r"\{.*\}", _text(resp), re.S)
    return json.loads(m.group(0))

def report(data):
    resp = client.messages.create(model=MODEL, max_tokens=800, messages=[{
        "role": "user", "content":
        f"Write a brief status report for the project owner with next recommended actions:\n{data}"}])
    return _text(resp)
