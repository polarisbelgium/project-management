import sqlite3, datetime as dt

DB = "agent.db"

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS project(id INTEGER PRIMARY KEY CHECK(id=1), description TEXT);
        CREATE TABLE IF NOT EXISTS prospects(
            id INTEGER PRIMARY KEY, name TEXT, company TEXT, email TEXT,
            why_fit TEXT, status TEXT DEFAULT 'new', last_contact TEXT);
        CREATE TABLE IF NOT EXISTS actions(
            id INTEGER PRIMARY KEY, prospect_id INTEGER, kind TEXT,
            subject TEXT, body TEXT, status TEXT DEFAULT 'pending', created TEXT);
        CREATE TABLE IF NOT EXISTS offers(
            id INTEGER PRIMARY KEY, prospect_id INTEGER, details TEXT, created TEXT);
        """)

def now():
    return dt.datetime.now().isoformat(timespec="seconds")
