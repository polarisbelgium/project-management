# Outreach Agent (human-approved)

Finds prospects, drafts proposals, follows up, tracks offers, reports to you.
**Nothing is sent without your approval** (`python main.py queue`).

## Setup (Windows, PowerShell)
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env     # then add your ANTHROPIC_API_KEY
```

## Workflow
```
python main.py project "Describe your project here"
python main.py research
python main.py draft
python main.py queue
python main.py followups   # run every few days, then queue again
python main.py offer 1 "They offered X"
python main.py report
```
Respect anti-spam laws (CAN-SPAM/GDPR): honest sender info, easy opt-out.
